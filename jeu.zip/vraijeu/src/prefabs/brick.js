// Documentation for Phaser's (2.6.2) sprites:: phaser.io/docs/2.6.2/Phaser.Sprite.html
class Brick extends Phaser.Sprite {

  // initialization code in the constructor
  constructor(game, x, y, frame) {
    super(game, x, y, 'brick_0', frame);

    this.anchor.setTo(0.5, 0.5);

    if (this.game.physics.arcade){
      this.game.physics.arcade.enableBody(this);
    }

    if (this.body){
      this.body.collideWorldBounds = true;
      this.body.bounce.set(1);
      this.body.immovable = true;
    }
      var n = Math.floor((Math.random() * 4) + 1);
      if (n == 1) {
          super(game, x, y, 'brick_0', frame);
      }
      else if (n == 2) {
          super(game, x, y, 'brick_1', frame);
      }
      else if (n == 3) {
          super(game, x, y, 'brick_2', frame);
      }
      else if (n == 4) {
          super(game, x, y, 'brick_3', frame);
      }
      else if (n == 5) {
          super(game, x, y, 'brick_4', frame);
      }
      else if (n == 6) {
          super(game, x, y, 'brick_5', frame);
      }
  }


  update() {

  }

}

export default Brick;
