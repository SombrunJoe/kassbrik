class Bonus extends Phaser.Sprite {
    constructor(game, x, y, frame) {
        super(game, x, y, 'bonus', frame);

        if (this.game.physics.arcade){
            this.game.physics.arcade.enableBody(this);
        }
        this.anchor.setTo(0.5, 0.5);

        if (this.body) {
            this.body.collideWorldBounds = true;
            this.body.bounce.set(1);
        }
    }


    update() {

    }
}

export default Bonus;




