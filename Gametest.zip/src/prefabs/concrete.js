class Concrete extends Phaser.Sprite {

    Constructor (game, x, y, frame) {
        super(game, x, y, 'concrete_0', frame);

        this.anchor.setTo(0.5, 0.5);

        if (this.game.physics.arcade){
            this.game.physics.arcade.enableBody(this);
        }

        if (this.body){
            this.body.collideWorldBounds = true;
            this.body.bounce.set(1);
            this.body.immovable = true;
        }
    }
}

export default Concrete;